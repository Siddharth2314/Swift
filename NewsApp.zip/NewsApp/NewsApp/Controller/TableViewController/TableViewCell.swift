//
//
//  TableViewCell.swift
//  NewsApp
//
//  Created by Siddharth Dave on 23/08/23.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var NewTitle: UILabel!
    @IBOutlet weak var NewsAuthor: UILabel!
    @IBOutlet weak var NewImage: UIImageView!
    @IBOutlet weak var NewsPublished: UILabel!
    
    @IBOutlet weak var NewsContent: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
