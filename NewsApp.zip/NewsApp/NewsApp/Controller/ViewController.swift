//
//  ViewController.swift
//  NewsApp
//
//  Created by Siddharth Dave on 23/08/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var Loader: UIActivityIndicatorView!
    @IBOutlet weak var TableView: UITableView!
    @IBOutlet weak var mySegment: UISegmentedControl!
    
    var searchController = UISearchController()
    
    var selectedType:Segments = .Everything
    
    var apiData = [Article]()
    var apiSource = [Sources]()
    
    var filterDate: [Article] = []
    var filterSource: [Sources] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        searchController = UISearchController(searchResultsController: nil)
        TableView.tableHeaderView = searchController.searchBar
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search by Title, Author or Series"
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.searchBar.tintColor = UIColor.orange
        
        UIActivityIndicator()
        
        self.registerTableView()
        self.getNewDate(segments: self.selectedType)
    }
    
    
    @IBAction func mySegmentTap(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex {
        case 0:
            self.selectedType = .Everything
        case 1:
            self.selectedType = .topHeadline
        case 2:
            self.selectedType = .Source
        default:
            self.selectedType = .Everything
        }
        
        getNewDate(segments: self.selectedType)
    }
    private func getNewDate(segments: Segments) {
        
        
        ApiHelper.sharedInstance.webServiceCall(type: segments.path) { [weak self] data, sourcesData in guard let self else { return }
            switch segments {
            case .Everything, .topHeadline:
                self.apiData = data
            case .Source:
                self.apiSource = sourcesData
            }
            DispatchQueue.main.async {
                self.TableView.reloadData()
                self.removeActivityIndicator()
            }
        }
    }
    func registerTableView() {
        
        self.TableView.delegate = self
        self.TableView.dataSource = self
        self.TableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        self.TableView.register(UINib(nibName: "TableViewCellSources", bundle: nil), forCellReuseIdentifier: "TableViewCellSources")
        self.TableView.rowHeight = UITableView.automaticDimension
        
    }
    
    
    private func UIActivityIndicator() {
        
        Loader =  UIActivityIndicatorView(style: .medium)
        
        Loader.color = .darkGray
        
        Loader.center = view.center
        
        Loader.hidesWhenStopped = false
        
        Loader.startAnimating()
        
        view?.addSubview(Loader)
    }
    
    
    private func removeActivityIndicator() {
        Loader.stopAnimating()
        Loader.removeFromSuperview()
    }
    
    
    
    
}



extension ViewController : UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if selectedType == .Source
        {
            guard let SourceCell = tableView.dequeueReusableCell(withIdentifier: "TableViewCellSources") as? TableViewCellSources else { return UITableViewCell() }
            
            SourceCell.SourceName.text = apiSource[indexPath.row].name
            SourceCell.SourceCountry.text = "Country : " + apiSource[indexPath.row].country
            SourceCell.SourceDescription.text = apiSource[indexPath.row].description
            
            return SourceCell
        }
        else {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as? TableViewCell else { return UITableViewCell()}
            
            
            let article: Article
            
            if searchController.isActive && (selectedType == .Everything || selectedType == .topHeadline) {
                        article = filterDate[indexPath.row]
                    } else {
                        article = apiData[indexPath.row]
                    }
            
            cell.NewTitle.text = apiData[indexPath.row].title
            cell.NewsAuthor.text = apiData[indexPath.row].author
            cell.NewsPublished.text = apiData[indexPath.row].publishedAt
            cell.NewsContent.text = apiData[indexPath.row].content
            if let imageUrlString = apiData[indexPath.row].urlToImage,
               let imageUrl = URL(string: imageUrlString) {
                
                URLSession.shared.dataTask(with: imageUrl) { data, response, error in
                    if let data = data, let image = UIImage(data: data) {
                        DispatchQueue.main.async {
                            cell.NewImage.image = image
                            
                        }
                    }
                }.resume()
            } else {
                cell.NewImage.image = nil
            }
            return cell
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchController.isActive && (selectedType == .Everything || selectedType == .topHeadline) {
            return filterDate.count
        }
            else if searchController.isActive && selectedType == .Source {
                return filterSource.count
            }
         else if selectedType == .Source {
            return apiSource.count
        } else {
            return apiData.count
        }
    }
}


extension ViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text {
            if selectedType == .Everything || selectedType == .topHeadline {
                filterDate = apiData.filter {
                    $0.title!.lowercased().contains(searchText.lowercased())
                }
            }
            else if selectedType == .Source {
                filterSource = apiSource.filter {
                    $0.name.lowercased().contains(searchText.lowercased())
                }
            }
            TableView.reloadData()
        }
    }
}


//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        if searchText != "" {
//            filterDate = apiData.filter({$0.title!.lowercased().uppercased().prefix(searchText.count) == searchText.lowercased().uppercased()})
//        }
//        TableView.reloadData()
//    }


