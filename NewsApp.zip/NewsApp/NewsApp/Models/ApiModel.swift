//
//  ApiModel.swift
//  NewsApp
//
//  Created by Siddharth Dave on 23/08/23.
//

import Foundation


struct ApiModel : Codable {
    
    let articles: [Article]
    
}

struct Article: Codable {
    
    let author: String?
    let title, description: String?
    let urlToImage: String?
    let publishedAt: String?
    let content: String?
}

