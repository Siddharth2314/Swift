//
//  APIModelSources.swift
//  NewsApp
//
//  Created by Siddharth Dave on 24/08/23.
//

import Foundation

struct ApiSource : Codable {
    
    let sources: [Sources]
    
}

struct Sources: Codable {

    let name, description: String
    let url: String
   // let category: Category?
    let language, country: String
}

enum Category: String, Codable {
    case business = "business"
    case entertainment = "entertainment"
    case general = "general"
    case health = "health"
    case science = "science"
    case sports = "sports"
    case technology = "technology"
}


