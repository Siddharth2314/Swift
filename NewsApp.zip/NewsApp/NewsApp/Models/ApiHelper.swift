//
//  ApiHelper.swift
//  NewsApp
//
//  Created by Siddharth Dave on 23/08/23.
//

import Foundation


class ApiHelper {
    
    static let sharedInstance = ApiHelper()
    
    
    func webServiceCall(type: String ,completion: @escaping ([Article],[Sources]) -> Void ) {
        
        guard let url = ApiURL.shared.baseURL else {
            return
        }
        
        let typeURL = url.appending(path:"\(type)")
        var queries: [URLQueryItem] = []
        
        if type == Segments.Everything.path {
            queries = [URLQueryItem(name: "q", value: "bitcoin"), URLQueryItem(name: "apikey", value: ApiURL.shared.api_key)]
        } else if type == Segments.topHeadline.path {
            queries = [URLQueryItem(name: "country", value: "us"), URLQueryItem(name: "apikey", value: ApiURL.shared.api_key)]
        }
        else {
            queries = [URLQueryItem(name: "apikey", value: ApiURL.shared.api_key)]
        }
        
        
        let queryUrl = typeURL.appending(queryItems: queries)
        
        
        let task = URLSession.shared.dataTask(with: queryUrl) { data, response, error in
            
            if let error = error {
                
                print("Error of \(error)")
                
            }
            
            guard let data = data else { return
                print(data ?? "")
            }
            
            if response != nil {
                
                let decoder = JSONDecoder()
                
                if type == Segments.Everything.path || type == Segments.topHeadline.path {
                    do {
                        let resData = try decoder.decode(ApiModel.self, from: data )
                        completion(resData.articles,[])
                    } catch{
                        print(error.localizedDescription)
                    }
                } else if type == Segments.Source.path {
                    do {
                        let respData = try decoder.decode(ApiSource.self, from: data )
                        completion([],respData.sources)
                        print(respData)
                    } catch{
                        print(error.localizedDescription)
                    }
                }
            }
        }
        task.resume()
    }
}


enum Segments: String {
    
    case Everything = "everything"
    case topHeadline = "top-headlines"
    case Source = "top-headings/sources"
    
    var path: String {
        switch self {
        case .Everything:
            return "everything"
        case .topHeadline:
            return "top-headlines"
        case .Source:
            return "top-headlines/sources"
        }
    }
}
