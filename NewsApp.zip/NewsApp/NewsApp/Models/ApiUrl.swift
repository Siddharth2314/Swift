//
//  ApiUrl.swift
//  NewsApp
//
//  Created by Siddharth Dave on 23/08/23.
//

import Foundation



class ApiURL {
    
    static let shared = ApiURL()
    
 //   let api_key = "9a03df02158f4a2a8d7f0a4a54890170"
    let api_key = "7fde20ebf89e44ae89eb04362f6acc4f"
    
    let baseURL = URL(string: "https://newsapi.org/v2")
    
   
}
